.. Artix_gen documentation master file, created by
   sphinx-quickstart on Mon Nov  7 13:13:37 2022.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to Artix_gen's documentation!
=====================================

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   main	
   conf
   modules	
   prim

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
