
************
Первая схема
************


.. image:: _static/artix.png
.. image:: _static/myDB.gif