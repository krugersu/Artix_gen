tlgrm module
============

.. automodule:: tlgrm
   :members:
   :undoc-members:
   :show-inheritance:
