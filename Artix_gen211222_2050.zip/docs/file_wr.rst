file\_wr module
===============

.. automodule:: file_wr
   :members:
   :undoc-members:
   :show-inheritance:
