tempCodeRunnerFile module
=========================

.. automodule:: tempCodeRunnerFile
   :members:
   :undoc-members:
   :show-inheritance:
