app\_logger module
==================

.. automodule:: app_logger
   :members:
   :undoc-members:
   :show-inheritance:
