diff\_data module
=================

.. automodule:: diff_data
   :members:
   :undoc-members:
   :show-inheritance:
