other module
============

.. automodule:: other
   :members:
   :undoc-members:
   :show-inheritance:
