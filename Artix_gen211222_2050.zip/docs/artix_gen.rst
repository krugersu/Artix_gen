artix\_gen module
=================

.. automodule:: artix_gen
   :members:
   :undoc-members:
   :show-inheritance:
