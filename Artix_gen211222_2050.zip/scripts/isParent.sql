SELECT inventcode, isParent, remain FROM invent WHERE isParent <> ''  
  
